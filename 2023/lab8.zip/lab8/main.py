from imio import Show, load


def main():
    base = load("main_in_base.png")
    pattern = load("main_in_pattern.png")

    # TODO

    # show
    show = Show()
    show.window("Base", base)
    show.window("Pattern", pattern)
    show.show()


if __name__ == "__main__":
    main()
