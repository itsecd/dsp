import cv2
import numpy as np
from corr2d import corr2d
from imio import Show, load, save


def bilinear_interpolate(x: np.ndarray, row: float, col: float) -> float:
    raise NotImplementedError()


def log_polar(src: np.ndarray, k: float) -> np.ndarray:
    assert len(src.shape) == 2 and src.shape[0] == src.shape[1]
    raise NotImplementedError()


class Peak:
    def __init__(self, row: int, col: int, angle: int, scale: float):
        self.row = row  # Позиция пика
        self.col = col  # Позиция пика
        self.angle = angle  # Соответствующий угол в градусах
        self.scale = scale  # Соответствующий масштаб

    def to_string(self, corr: float) -> str:
        return f"corr[{self.row:3d}, {self.col:3d}]={corr:.2f}     angle={self.angle:4d}     scale={self.scale:.2f}"


class LogPolarMatch:
    def __init__(
        self,
        base_s_lp: np.ndarray,
        pattern_s_lp: np.ndarray,
        corr_raw: np.ndarray,
        corr: np.ndarray,
        peaks: list[Peak],
    ):
        self.base_s_lp = base_s_lp
        self.pattern_s_lp = pattern_s_lp
        self.corr_raw = corr_raw
        self.corr = corr
        self.peaks = peaks


def log_polar_match(
    base_s: np.ndarray,
    pattern_s: np.ndarray,
    k: float = 50,
    corr_threshold: float = 0.9,
    dilate_kernel_size: int = 3,
) -> LogPolarMatch:
    assert len(base_s.shape) == 2 and len(pattern_s.shape) == 2
    assert base_s.shape[0] == base_s.shape[1]
    assert base_s.shape[1] == pattern_s.shape[0]
    assert pattern_s.shape[0] == pattern_s.shape[1]

    base_s_lp = log_polar(base_s, k)
    pattern_s_lp = log_polar(pattern_s, k)

    raise NotImplementedError()


def main():
    # load
    base_s = load("log_polar_in_base_s.png")
    pattern_s = load("log_polar_in_pattern_s.png")

    # process
    r = log_polar_match(base_s, pattern_s)
    
    for peak in r.peaks:
        print(peak.to_string(r.corr[peak.row, peak.col]))
    
    save("log_polar_out_base_s_lp.png", r.base_s_lp)
    save("log_polar_out_pattern_s_lp.png", r.pattern_s_lp)
    save("log_polar_out_corr_raw.png", r.corr_raw)
    save("log_polar_out_corr.png", r.corr)

    # show
    show = Show()
    show.window("Base Spectrum (Cartesian)", base_s)
    show.window("Pattern Spectrum (Cartesian)", pattern_s)
    show.window("Base Spectrum (Log-Polar)", r.base_s_lp)
    show.window("Pattern Spectrum (Log-Polar)", r.pattern_s_lp)
    show.window("Corr (Log-Polar, Raw)", r.corr_raw)
    show.window("Corr (Log-Polar, Filtered)", r.corr)
    show.show()


if __name__ == "__main__":
    main()
