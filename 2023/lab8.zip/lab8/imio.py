import cv2
import numpy as np


def normalize(data: np.ndarray) -> np.ndarray:
    assert len(data.shape) == 2 and data.dtype == np.float64

    data_min = np.min(data)
    data_max = np.max(data)
    data = (data - data_min) / (data_max - data_min)

    return data


def load(path: str) -> np.ndarray:
    return cv2.imread(path, cv2.IMREAD_GRAYSCALE).astype(np.float64) / 255


def save(path: str, data: np.ndarray, norm: bool = False) -> None:
    assert len(data.shape) == 2 and data.dtype == np.float64

    if norm:
        data = normalize(data)

    data = np.round(data * 255).astype(np.uint8)

    cv2.imwrite(path, data)


class Show:
    def window(self, title: str, data: np.ndarray) -> None:
        cv2.namedWindow(title, cv2.WINDOW_NORMAL)
        cv2.imshow(title, data)

    def show(self) -> None:
        cv2.waitKey()
