from typing import Optional, Tuple

import numpy as np
from imio import Show, load, normalize, save


def corr2d_unnormalized(base: np.ndarray, pattern: np.ndarray) -> np.ndarray:
    assert len(base.shape) == 2 and len(pattern.shape) == 2
    raise NotImplementedError()


def corr2d(base: np.ndarray, pattern: np.ndarray) -> np.ndarray:
    assert len(base.shape) == 2 and len(pattern.shape) == 2
    raise NotImplementedError()


def get_quarter_maxs(
    corr: np.ndarray, pattern_shape: Tuple[int, ...]
) -> Tuple[float, float, float, float]:
    half_h = corr.shape[0] // 2 + pattern_shape[0] // 2
    half_w = corr.shape[1] // 2 + pattern_shape[1] // 2
    max1 = np.round(np.max(corr[:half_h, :half_w]), 2)
    max2 = np.round(np.max(corr[:half_h, half_w:]), 2)
    max3 = np.round(np.max(corr[half_h:, :half_w]), 2)
    max4 = np.round(np.max(corr[half_h:, half_w:]), 2)
    return max1, max2, max3, max4


def main():
    # Загрузка
    base = load("corr2d_in_base.png")
    pattern = load("corr2d_in_pattern.png")

    # Обработка
    unnormalized_corr = corr2d_unnormalized(base, pattern)
    print(get_quarter_maxs(unnormalized_corr, pattern.shape))
    normalized_corr = corr2d(base, pattern)
    print(get_quarter_maxs(normalized_corr, pattern.shape))

    # Контрастирование к диапазону [0; 1] для сохранения и отображения
    unnormalized_corr = normalize(unnormalized_corr)

    # Сохранение
    save("corr2d_out_unnormalized.png", unnormalized_corr)
    save("corr2d_out_normalized.png", normalized_corr)

    # Отображение
    show = Show()
    show.window("Base", base)
    show.window("Pattern", pattern)
    show.window("Unnormalized Corr", unnormalized_corr)
    show.window("Normalized Corr", normalized_corr)
    show.show()


if __name__ == "__main__":
    main()
