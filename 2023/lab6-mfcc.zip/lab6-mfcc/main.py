from datetime import timedelta
from time import time_ns
from typing import Final, Tuple

import librosa
import numpy as np
from mfcc import build_context, compute_mfcc
from samples import load_samples
from scipy.io.wavfile import read

TEMPLATES_DIR: Final[str] = "data"
TEST_FILE: Final[str] = "test.wav"

SEGMENT_LENGTH_MS: Final[float] = 20.0
BAND_WIDTH_MEL: Final[float] = 450.0
MFCC_N = 8


def test(test_file: str) -> None:
    # load audio samples

    samples = load_samples(TEMPLATES_DIR)
    print(samples)
    print()

    # build context

    context = build_context(samples, SEGMENT_LENGTH_MS, BAND_WIDTH_MEL, MFCC_N)
    print(context)
    print()

    # compute mfcc for audio samples

    mfcc_list = list[Tuple[str, np.ndarray]]()

    t1 = time_ns()

    for key, data_list in samples.dict.items():
        for data in data_list:
            mfcc_list.append((key, compute_mfcc(data, context)))

    t2 = time_ns()

    print(f"Compute {len(mfcc_list)} mfcc in {(t2-t1) / 1000000} ms")

    # matching

    rate, data = read(test_file)
    assert isinstance(rate, int)
    assert isinstance(data, np.ndarray)

    bulk_n = (context.segment_max_count // 2 - 1) * context.segment_n
    idx = bulk_n

    while idx < len(data):
        current_mfcc = compute_mfcc(data[idx - bulk_n : idx], context)

        for key, pattern_mfcc in mfcc_list:
            # TODO-5 Вычислить вес (меру несхожести) между матрицами current_mfcc (анализируемый фрагмент) и pattern_mfcc (образец произнесения слова key).
            # Из всех итераций цикла необходимо выбрать key/pattern_mfcc с минимальным весом.
            pass

        # TODO-5 Если минимальный вес не превышет некоторый экспериментально подобранный порог,
        # то считать, что в анализируемом фрагменте обнаружен образец.
        # Рассчитать время начала этого образца в глобальном времени (в секундах относительно data) и вывести распозанное слово (key) и временную метку его произношения.

        idx += bulk_n // 4


if __name__ == "__main__":
    test(TEST_FILE)
